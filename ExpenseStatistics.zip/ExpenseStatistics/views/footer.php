<?php
$html ='<footer>
                <nav class="navbar fixed-bottom navbar-expand-lg navbar-light bg-light"> 
                    
                    <ul class="navbar-nav mr-auto">
                    <li>Copyright @Liang Jianquan</li>
                    </ul> 
                    
                </nav>
                    
            </footer>
            
            ';
echo $html

            ?>